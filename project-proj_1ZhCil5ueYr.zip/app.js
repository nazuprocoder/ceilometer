const { useState, useEffect, useRef } = React;

function App() {
  const [booting, setBooting] = useState(true);
  const [startMenuOpen, setStartMenuOpen] = useState(false);
  const [windows, setWindows] = useState([]);
  const [time, setTime] = useState(new Date());
  const [showBSOD, setShowBSOD] = useState(false);
  const [draggedWindow, setDraggedWindow] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [resizingWindow, setResizingWindow] = useState(null);
  const [resizeDirection, setResizeDirection] = useState(null);
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0 });

  useEffect(() => {
    const bootTimer = setTimeout(() => setBooting(false), 3000);
    const clockTimer = setInterval(() => setTime(new Date()), 1000);
    return () => {
      clearTimeout(bootTimer);
      clearInterval(clockTimer);
    };
  }, []);

  const apps = [
    { id: 'file-explorer', title: 'File Explorer', icon: 'fa-folder-open', color: '#ffd66b' },
    { id: 'notepad', title: 'Notepad', icon: 'fa-file-lines', color: '#4cc2ff' },
    { id: 'terminal', title: 'Terminal', icon: 'fa-terminal', color: '#fff' },
    { id: 'edge', title: 'Browser', icon: 'fa-edge fa-brands', color: '#00ca7d' },
    { id: 'calculator', title: 'Calculator', icon: 'fa-calculator', color: '#fff' },
    { id: 'game', title: 'Cyber Snake', icon: 'fa-gamepad', color: '#adff2f' },
    { id: 'paint', title: 'Paint', icon: 'fa-palette', color: '#e05194' },
    { id: 'vscode', title: 'Code Editor', icon: 'fa-code', color: '#0078d4' },
    { id: 'video', title: 'Video Editor', icon: 'fa-film', color: '#9b59b6' },
    { id: 'music', title: 'Music Player', icon: 'fa-music', color: '#ff6b6b' },
    { id: 'settings', title: 'Settings', icon: 'fa-gear', color: '#95a5a6' }
  ];

  const openApp = (appId) => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;
    
    const offset = windows.length * 30;
    const maxOffset = 200;
    const actualOffset = offset % maxOffset;
    
    const maxZ = windows.length > 0 ? Math.max(...windows.map(w => w.zIndex || 100)) : 100;
    
    const newWindow = {
      id: `win-${Date.now()}`,
      appId: app.id,
      title: app.title,
      icon: app.icon,
      color: app.color,
      x: 100 + actualOffset,
      y: 50 + actualOffset,
      width: 800,
      height: 500,
      minimized: false,
      maximized: false,
      zIndex: maxZ + 1
    };
    
    setWindows([...windows, newWindow]);
    setStartMenuOpen(false);
  };

  const closeWindow = (id) => {
    setWindows(windows.filter(w => w.id !== id));
  };

  const minimizeWindow = (id) => {
    setWindows(windows.map(w => w.id === id ? {...w, minimized: true} : w));
  };

  const restoreWindow = (id) => {
    setWindows(windows.map(w => w.id === id ? {...w, minimized: false} : w));
  };

  const toggleMaximize = (id) => {
    setWindows(windows.map(w => w.id === id ? {...w, maximized: !w.maximized} : w));
  };

  const bringToFront = (id) => {
    const maxZ = Math.max(...windows.map(w => w.zIndex || 100), 100);
    setWindows(windows.map(w => w.id === id ? {...w, zIndex: maxZ + 1} : w));
  };

  const handleMouseDown = (e, id) => {
    if (e.target.closest('.window-controls')) return;
    if (e.target.closest('.resize-handle')) return;
    const win = windows.find(w => w.id === id);
    if (!win || win.maximized) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    setDraggedWindow(id);
    bringToFront(id);
  };

  const handleResizeStart = (e, id, direction) => {
    e.stopPropagation();
    const win = windows.find(w => w.id === id);
    if (!win || win.maximized) return;
    
    setResizingWindow(id);
    setResizeDirection(direction);
    setResizeStart({
      x: e.clientX,
      y: e.clientY,
      width: win.width,
      height: win.height,
      winX: win.x,
      winY: win.y
    });
    bringToFront(id);
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (draggedWindow) {
        const win = windows.find(w => w.id === draggedWindow);
        if (!win) return;

        setWindows(windows.map(w => {
          if (w.id === draggedWindow) {
            return {
              ...w,
              x: e.clientX - dragOffset.x,
              y: Math.max(0, e.clientY - dragOffset.y)
            };
          }
          return w;
        }));
      }

      if (resizingWindow) {
        const deltaX = e.clientX - resizeStart.x;
        const deltaY = e.clientY - resizeStart.y;

        setWindows(windows.map(w => {
          if (w.id === resizingWindow) {
            let newWidth = w.width;
            let newHeight = w.height;
            let newX = w.x;
            let newY = w.y;

            if (resizeDirection.includes('e')) {
              newWidth = Math.max(300, resizeStart.width + deltaX);
            }
            if (resizeDirection.includes('s')) {
              newHeight = Math.max(200, resizeStart.height + deltaY);
            }
            if (resizeDirection.includes('w')) {
              const newW = Math.max(300, resizeStart.width - deltaX);
              if (newW > 300) {
                newX = resizeStart.winX + deltaX;
                newWidth = newW;
              }
            }
            if (resizeDirection.includes('n')) {
              const newH = Math.max(200, resizeStart.height - deltaY);
              if (newH > 200) {
                newY = Math.max(0, resizeStart.winY + deltaY);
                newHeight = newH;
              }
            }

            return { ...w, width: newWidth, height: newHeight, x: newX, y: newY };
          }
          return w;
        }));
      }
    };

    const handleMouseUp = () => {
      setDraggedWindow(null);
      setResizingWindow(null);
      setResizeDirection(null);
    };

    if (draggedWindow || resizingWindow) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [draggedWindow, resizingWindow, dragOffset, resizeDirection, resizeStart, windows]);

  if (booting) {
    return (
      <div id="boot-screen">
        <i className="fa-brands fa-windows" style={{fontSize: '64px', marginBottom: '40px', color: '#00a2ed'}}></i>
        <div className="spinner"></div>
        <div>Starting AuraOS...</div>
      </div>
    );
  }

  if (showBSOD) {
    return (
      <div id="bsod" style={{display: 'flex'}}>
        <h1>:(</h1>
        <p>Your PC ran into a problem and needs to restart. We're just collecting some error info, and then we'll restart for you.</p>
        <p style={{fontSize: '16px', marginTop: '30px'}}>Stop Code: CRITICAL_PROCESS_DIED</p>
      </div>
    );
  }

  return (
    <div id="desktop">
      <div id="desktop-icons">
        {apps.map(app => (
          <div key={app.id} className="d-icon" data-app={app.id} onDoubleClick={() => openApp(app.id)}>
            <i className={`fa-solid ${app.icon}`} style={{color: app.color}}></i>
            <span>{app.title}</span>
          </div>
        ))}
      </div>

      {windows.map(win => !win.minimized && (
        <div key={win.id} 
             className={`window ${win.maximized ? 'maximized' : ''}`} 
             style={win.maximized ? {zIndex: win.zIndex || 100} : {
               left: win.x, 
               top: win.y, 
               width: win.width, 
               height: win.height,
               zIndex: win.zIndex || 100
             }}
             onClick={() => bringToFront(win.id)}>
          <div className="title-bar" onMouseDown={(e) => handleMouseDown(e, win.id)}>
            <div className="title-bar-text">
              <i className={`fa-solid ${win.icon}`} style={{color: win.color}}></i> {win.title}
            </div>
            <div className="window-controls">
              <div className="win-btn" onClick={(e) => { e.stopPropagation(); minimizeWindow(win.id); }}>
                <i className="fa-solid fa-minus"></i>
              </div>
              <div className="win-btn" onClick={(e) => { e.stopPropagation(); toggleMaximize(win.id); }}>
                <i className="fa-regular fa-square"></i>
              </div>
              <div className="win-btn close" onClick={(e) => { e.stopPropagation(); closeWindow(win.id); }}>
                <i className="fa-solid fa-xmark"></i>
              </div>
            </div>
          </div>
          <div className="window-content">
            {win.appId === 'notepad' && <NotepadApp />}
            {win.appId === 'terminal' && <TerminalApp />}
            {win.appId === 'file-explorer' && <FileExplorerApp />}
            {win.appId === 'calculator' && <CalculatorApp />}
            {win.appId === 'edge' && <BrowserApp />}
            {win.appId === 'game' && <SnakeGameApp />}
            {win.appId === 'paint' && <PaintApp />}
            {win.appId === 'vscode' && <CodeEditorApp />}
            {win.appId === 'video' && <VideoEditorApp />}
            {win.appId === 'music' && <MusicPlayerApp />}
            {win.appId === 'settings' && <SettingsApp />}
          </div>
          {!win.maximized && (
            <>
              <div className="resize-handle resize-n" onMouseDown={(e) => handleResizeStart(e, win.id, 'n')}></div>
              <div className="resize-handle resize-s" onMouseDown={(e) => handleResizeStart(e, win.id, 's')}></div>
              <div className="resize-handle resize-e" onMouseDown={(e) => handleResizeStart(e, win.id, 'e')}></div>
              <div className="resize-handle resize-w" onMouseDown={(e) => handleResizeStart(e, win.id, 'w')}></div>
              <div className="resize-handle resize-ne" onMouseDown={(e) => handleResizeStart(e, win.id, 'ne')}></div>
              <div className="resize-handle resize-nw" onMouseDown={(e) => handleResizeStart(e, win.id, 'nw')}></div>
              <div className="resize-handle resize-se" onMouseDown={(e) => handleResizeStart(e, win.id, 'se')}></div>
              <div className="resize-handle resize-sw" onMouseDown={(e) => handleResizeStart(e, win.id, 'sw')}></div>
            </>
          )}
        </div>
      ))}

      <div id="start-menu" className={startMenuOpen ? 'open' : ''}>
        <div className="search-bar">
          <i className="fa-solid fa-magnifying-glass"></i>
          <input type="text" placeholder="Type here to search" />
        </div>
        <div style={{fontWeight: 600, marginBottom: '10px', fontSize: '14px'}}>Pinned</div>
        <div className="pinned-apps">
          {apps.map(app => (
            <div key={app.id} className="app-item" onClick={() => openApp(app.id)}>
              <i className={`fa-solid ${app.icon}`} style={{color: app.color}}></i>
              <span>{app.title}</span>
            </div>
          ))}
        </div>
        <div style={{marginTop: 'auto', paddingTop: '15px', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
            <div style={{width: '32px', height: '32px', background: '#555', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center', color: 'white'}}>
              <i className="fa-solid fa-user"></i>
            </div>
            <span style={{fontSize: '12px', fontWeight: 600}}>User</span>
          </div>
          <i className="fa-solid fa-power-off" style={{cursor: 'pointer', padding: '8px'}} onClick={() => setShowBSOD(true)}></i>
        </div>
      </div>

      <div id="taskbar">
        <div style={{display: 'flex', gap: '5px'}}></div>
        <div className="taskbar-center">
          <div className="tb-icon" id="start-btn" onClick={() => setStartMenuOpen(!startMenuOpen)}>
            <i className="fa-brands fa-windows"></i>
          </div>
          {windows.map(win => (
            <div key={win.id} className={`tb-icon ${!win.minimized ? 'active' : ''}`} 
                 onClick={() => win.minimized ? restoreWindow(win.id) : minimizeWindow(win.id)}>
              <i className={`fa-solid ${win.icon}`}></i>
            </div>
          ))}
        </div>
        <div className="taskbar-right">
          <i className="fa-solid fa-wifi"></i>
          <i className="fa-solid fa-volume-high"></i>
          <div id="clock">
            <div style={{fontWeight: 600}}>{time.toLocaleTimeString('en-US', {hour: '2-digit', minute: '2-digit'})}</div>
            <div>{time.toLocaleDateString('en-US', {month: '2-digit', day: '2-digit', year: 'numeric'})}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);