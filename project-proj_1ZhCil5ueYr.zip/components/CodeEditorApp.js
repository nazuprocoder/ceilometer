function CodeEditorApp() {
  const [code, setCode] = React.useState(`// Welcome to AuraOS Code Editor
function hello() {
  console.log("Hello, World!");
}

hello();`);
  const [language, setLanguage] = React.useState('javascript');
  const [output, setOutput] = React.useState('');
  const [running, setRunning] = React.useState(false);

  const lineCount = code.split('\n').length;

  const runCode = async () => {
    setRunning(true);
    setOutput('Running...');
    
    if (language === 'javascript') {
      try {
        const result = eval(code);
        setOutput(result !== undefined ? String(result) : 'Code executed successfully');
      } catch (error) {
        setOutput(`Error: ${error.message}`);
      }
    } else if (language === 'python') {
      try {
        const systemPrompt = `You are a Python interpreter. Execute the given Python code and return ONLY the output. If there's an error, return the error message.`;
        const result = await invokeAIAgent(systemPrompt, code);
        setOutput(result);
      } catch (error) {
        setOutput(`Error: ${error.message}`);
      }
    }
    setRunning(false);
  };

  return (
    <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
      <div style={{
        padding: '10px',
        borderBottom: '1px solid var(--border-color)',
        display: 'flex',
        gap: '15px',
        fontSize: '12px',
        alignItems: 'center',
        background: '#2d2d30'
      }}>
        <span style={{cursor: 'pointer', color: '#ccc'}}>File</span>
        <span style={{cursor: 'pointer', color: '#ccc'}}>Edit</span>
        <span style={{cursor: 'pointer', color: '#ccc'}}>View</span>
        <select 
          value={language} 
          onChange={(e) => setLanguage(e.target.value)}
          style={{background: '#1e1e1e', color: '#ccc', border: '1px solid #444', padding: '3px 8px', borderRadius: '3px'}}
        >
          <option value="javascript">JavaScript</option>
          <option value="python">Python</option>
        </select>
        <button 
          onClick={runCode}
          disabled={running}
          style={{
            background: '#0e639c',
            color: 'white',
            border: 'none',
            padding: '5px 15px',
            borderRadius: '3px',
            cursor: running ? 'not-allowed' : 'pointer',
            opacity: running ? 0.5 : 1
          }}
        >
          <i className="fa-solid fa-play" style={{marginRight: '5px'}}></i>
          Run
        </button>
        <span style={{marginLeft: 'auto', color: '#888', fontSize: '11px'}}>Lines: {lineCount}</span>
      </div>
      <div style={{display: 'flex', flex: 1, overflow: 'hidden'}}>
        <div style={{
          width: '40px',
          background: '#1e1e1e',
          borderRight: '1px solid #444',
          padding: '10px 5px',
          textAlign: 'right',
          fontSize: '14px',
          color: '#858585',
          fontFamily: 'Consolas, monospace',
          userSelect: 'none',
          overflow: 'hidden'
        }}>
          {Array.from({length: lineCount}, (_, i) => (
            <div key={i} style={{lineHeight: '1.6'}}>{i + 1}</div>
          ))}
        </div>
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          style={{
            flex: 1,
            padding: '10px',
            border: 'none',
            outline: 'none',
            fontFamily: 'Consolas, monospace',
            fontSize: '14px',
            background: '#1e1e1e',
            color: '#d4d4d4',
            resize: 'none',
            lineHeight: '1.6'
          }}
        />
      </div>
      {output && (
        <div style={{
          height: '150px',
          borderTop: '1px solid #444',
          background: '#1e1e1e',
          color: '#ccc',
          padding: '10px',
          fontFamily: 'Consolas, monospace',
          fontSize: '13px',
          overflow: 'auto'
        }}>
          <div style={{color: '#4ec9b0', marginBottom: '5px'}}>Output:</div>
          <pre style={{margin: 0, whiteSpace: 'pre-wrap'}}>{output}</pre>
        </div>
      )}
    </div>
  );
}
