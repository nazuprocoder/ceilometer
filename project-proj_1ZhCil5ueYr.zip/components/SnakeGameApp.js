function SnakeGameApp() {
  const canvasRef = React.useRef(null);
  const [score, setScore] = React.useState(0);
  const [gameOver, setGameOver] = React.useState(false);
  const [gameStarted, setGameStarted] = React.useState(false);
  const gameLoop = React.useRef(null);

  const gridSize = 20;
  const tileCount = 20;

  const snake = React.useRef([{ x: 10, y: 10 }]);
  const direction = React.useRef({ x: 0, y: 0 });
  const food = React.useRef({ x: 15, y: 15 });

  const startGame = () => {
    snake.current = [{ x: 10, y: 10 }];
    direction.current = { x: 1, y: 0 };
    food.current = { 
      x: Math.floor(Math.random() * tileCount), 
      y: Math.floor(Math.random() * tileCount) 
    };
    setScore(0);
    setGameOver(false);
    setGameStarted(true);
  };

  React.useEffect(() => {
    const handleKeyPress = (e) => {
      if (!gameStarted || gameOver) return;
      
      switch(e.key) {
        case 'ArrowUp':
          if (direction.current.y === 0) direction.current = { x: 0, y: -1 };
          break;
        case 'ArrowDown':
          if (direction.current.y === 0) direction.current = { x: 0, y: 1 };
          break;
        case 'ArrowLeft':
          if (direction.current.x === 0) direction.current = { x: -1, y: 0 };
          break;
        case 'ArrowRight':
          if (direction.current.x === 0) direction.current = { x: 1, y: 0 };
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameStarted, gameOver]);

  React.useEffect(() => {
    if (!gameStarted || gameOver) return;

    gameLoop.current = setInterval(() => {
      const head = { ...snake.current[0] };
      head.x += direction.current.x;
      head.y += direction.current.y;

      if (head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount) {
        setGameOver(true);
        return;
      }

      for (let segment of snake.current) {
        if (segment.x === head.x && segment.y === head.y) {
          setGameOver(true);
          return;
        }
      }

      snake.current.unshift(head);

      if (head.x === food.current.x && head.y === food.current.y) {
        setScore(s => s + 10);
        food.current = {
          x: Math.floor(Math.random() * tileCount),
          y: Math.floor(Math.random() * tileCount)
        };
      } else {
        snake.current.pop();
      }

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      
      ctx.fillStyle = '#001100';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = '#0f0';
      for (let segment of snake.current) {
        ctx.fillRect(segment.x * gridSize, segment.y * gridSize, gridSize - 2, gridSize - 2);
      }

      ctx.fillStyle = '#f00';
      ctx.fillRect(food.current.x * gridSize, food.current.y * gridSize, gridSize - 2, gridSize - 2);
    }, 100);

    return () => clearInterval(gameLoop.current);
  }, [gameStarted, gameOver]);

  return (
    <div className="game-container">
      <div className="game-ui">
        <div>Score: {score}</div>
        <div>High Score: {Math.max(score, 0)}</div>
      </div>
      <canvas 
        ref={canvasRef}
        id="game-canvas"
        width={400}
        height={400}
      />
      {gameOver && (
        <div className="game-over-overlay" style={{display: 'block'}}>
          <h1>GAME OVER</h1>
          <p>Score: {score}</p>
          <button className="neon-btn" onClick={startGame}>Restart</button>
        </div>
      )}
      {!gameStarted && !gameOver && (
        <div className="game-over-overlay" style={{display: 'block'}}>
          <h1 style={{color: '#0f0'}}>CYBER SNAKE</h1>
          <p>Use arrow keys to move</p>
          <button className="neon-btn" onClick={startGame}>Start Game</button>
        </div>
      )}
    </div>
  );
}