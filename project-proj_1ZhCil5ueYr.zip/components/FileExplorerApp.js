function FileExplorerApp() {
  const [currentPath, setCurrentPath] = React.useState('Desktop');
  const [viewMode, setViewMode] = React.useState('grid');
  const [selectedFile, setSelectedFile] = React.useState(null);
  
  const fileStructure = {
    'Desktop': [
      { name: 'Documents', type: 'folder', icon: 'fa-folder', size: '--', modified: '2025-10-15' },
      { name: 'Pictures', type: 'folder', icon: 'fa-folder', size: '--', modified: '2025-10-10' },
      { name: 'Welcome.txt', type: 'txt', icon: 'fa-file-lines', size: '2 KB', modified: '2025-10-20' },
      { name: 'Project', type: 'folder', icon: 'fa-folder', size: '--', modified: '2025-10-18' },
      { name: 'script.js', type: 'js', icon: 'fa-file-code', size: '5 KB', modified: '2025-10-19' }
    ],
    'Documents': [
      { name: 'Resume.pdf', type: 'pdf', icon: 'fa-file-pdf', size: '145 KB', modified: '2025-09-20' },
      { name: 'Report.docx', type: 'docx', icon: 'fa-file-word', size: '78 KB', modified: '2025-10-05' }
    ],
    'Pictures': [
      { name: 'Vacation.jpg', type: 'jpg', icon: 'fa-file-image', size: '2.3 MB', modified: '2025-08-15' },
      { name: 'Screenshot.png', type: 'png', icon: 'fa-file-image', size: '856 KB', modified: '2025-10-12' }
    ]
  };

  const files = fileStructure[currentPath] || [];

  const navigateTo = (folderName) => {
    if (fileStructure[folderName]) {
      setCurrentPath(folderName);
      setSelectedFile(null);
    }
  };

  return (
    <div className="fe-container">
      <div className="fe-toolbar">
        <i className="fa-solid fa-arrow-left" style={{cursor: 'pointer', opacity: currentPath === 'Desktop' ? 0.3 : 1}} onClick={() => currentPath !== 'Desktop' && setCurrentPath('Desktop')}></i>
        <i className="fa-solid fa-arrow-right" style={{cursor: 'pointer', opacity: 0.3}}></i>
        <i className="fa-solid fa-arrow-up" style={{cursor: 'pointer'}} onClick={() => setCurrentPath('Desktop')}></i>
        <div className="fe-path">
          <i className="fa-solid fa-folder" style={{marginRight: '5px'}}></i>
          {currentPath}
        </div>
        <div style={{marginLeft: 'auto', display: 'flex', gap: '10px'}}>
          <i className={`fa-solid fa-grip ${viewMode === 'grid' ? 'active' : ''}`} style={{cursor: 'pointer', padding: '5px'}} onClick={() => setViewMode('grid')}></i>
          <i className={`fa-solid fa-list ${viewMode === 'list' ? 'active' : ''}`} style={{cursor: 'pointer', padding: '5px'}} onClick={() => setViewMode('list')}></i>
        </div>
      </div>
      <div className="fe-body">
        <div className="fe-sidebar">
          <div onClick={() => navigateTo('Desktop')}><i className="fa-solid fa-desktop"></i> Desktop</div>
          <div onClick={() => navigateTo('Documents')}><i className="fa-solid fa-file"></i> Documents</div>
          <div onClick={() => navigateTo('Pictures')}><i className="fa-solid fa-image"></i> Pictures</div>
          <div><i className="fa-solid fa-download"></i> Downloads</div>
          <div><i className="fa-solid fa-music"></i> Music</div>
          <div><i className="fa-solid fa-video"></i> Videos</div>
        </div>
        <div className={`fe-content ${viewMode}`}>
          {files.map((file, i) => (
            <div 
              key={i} 
              className={`file-item ${selectedFile === i ? 'selected' : ''}`}
              data-type={file.type}
              onClick={() => setSelectedFile(i)}
              onDoubleClick={() => file.type === 'folder' && navigateTo(file.name)}
            >
              {viewMode === 'grid' ? (
                <>
                  <i className={`fa-solid ${file.icon}`}></i>
                  <span>{file.name}</span>
                </>
              ) : (
                <div style={{display: 'flex', width: '100%', justifyContent: 'space-between', padding: '5px'}}>
                  <div style={{display: 'flex', gap: '10px', alignItems: 'center'}}>
                    <i className={`fa-solid ${file.icon}`}></i>
                    <span>{file.name}</span>
                  </div>
                  <div style={{display: 'flex', gap: '30px', fontSize: '11px', color: '#888'}}>
                    <span>{file.modified}</span>
                    <span>{file.size}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
