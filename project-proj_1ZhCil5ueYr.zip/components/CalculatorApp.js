function CalculatorApp() {
  const [display, setDisplay] = React.useState('0');
  const [prevValue, setPrevValue] = React.useState(null);
  const [operation, setOperation] = React.useState(null);
  const [newNumber, setNewNumber] = React.useState(true);

  const handleNumber = (num) => {
    if (newNumber) {
      setDisplay(String(num));
      setNewNumber(false);
    } else {
      setDisplay(display === '0' ? String(num) : display + num);
    }
  };

  const handleOperation = (op) => {
    const current = parseFloat(display);
    if (prevValue === null) {
      setPrevValue(current);
    } else if (operation) {
      const result = calculate(prevValue, current, operation);
      setDisplay(String(result));
      setPrevValue(result);
    }
    setOperation(op);
    setNewNumber(true);
  };

  const calculate = (a, b, op) => {
    switch(op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return a / b;
      default: return b;
    }
  };

  const handleEquals = () => {
    if (operation && prevValue !== null) {
      const result = calculate(prevValue, parseFloat(display), operation);
      setDisplay(String(result));
      setPrevValue(null);
      setOperation(null);
      setNewNumber(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setPrevValue(null);
    setOperation(null);
    setNewNumber(true);
  };

  const Button = ({ value, onClick, className = '' }) => (
    <button 
      onClick={onClick}
      style={{
        padding: '20px',
        fontSize: '18px',
        border: '1px solid var(--border-color)',
        background: 'var(--window-bg)',
        cursor: 'pointer',
        transition: '0.2s'
      }}
      onMouseEnter={(e) => e.target.style.background = 'rgba(128,128,128,0.1)'}
      onMouseLeave={(e) => e.target.style.background = 'var(--window-bg)'}
      className={className}
    >
      {value}
    </button>
  );

  return (
    <div style={{padding: '10px', display: 'flex', flexDirection: 'column', gap: '10px'}}>
      <div style={{
        padding: '20px',
        background: 'rgba(128,128,128,0.05)',
        textAlign: 'right',
        fontSize: '32px',
        fontWeight: 'bold',
        borderRadius: '4px',
        border: '1px solid var(--border-color)'
      }}>
        {display}
      </div>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '5px'}}>
        <Button value="C" onClick={handleClear} />
        <Button value="÷" onClick={() => handleOperation('÷')} />
        <Button value="×" onClick={() => handleOperation('×')} />
        <Button value="-" onClick={() => handleOperation('-')} />
        
        <Button value="7" onClick={() => handleNumber(7)} />
        <Button value="8" onClick={() => handleNumber(8)} />
        <Button value="9" onClick={() => handleNumber(9)} />
        <Button value="+" onClick={() => handleOperation('+')} />
        
        <Button value="4" onClick={() => handleNumber(4)} />
        <Button value="5" onClick={() => handleNumber(5)} />
        <Button value="6" onClick={() => handleNumber(6)} />
        <Button value="=" onClick={handleEquals} style={{gridRow: 'span 2'}} />
        
        <Button value="1" onClick={() => handleNumber(1)} />
        <Button value="2" onClick={() => handleNumber(2)} />
        <Button value="3" onClick={() => handleNumber(3)} />
        
        <Button value="0" onClick={() => handleNumber(0)} style={{gridColumn: 'span 2'}} />
        <Button value="." onClick={() => handleNumber('.')} />
      </div>
    </div>
  );
}