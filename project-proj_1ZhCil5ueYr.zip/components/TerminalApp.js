function TerminalApp() {
  const [history, setHistory] = React.useState([
    'AuraOS Terminal [Version 1.0.0]',
    '(c) 2025 AuraOS Corporation. All rights reserved.',
    ''
  ]);
  const [input, setInput] = React.useState('');
  const [processing, setProcessing] = React.useState(false);
  const inputRef = React.useRef(null);

  const executePython = async (code) => {
    try {
      const systemPrompt = `You are a Python interpreter. Execute the given Python code and return ONLY the output that would appear in the console. Do not include any explanations, markdown formatting, or extra text. If there's an error, return the error message as it would appear in Python.`;
      const userPrompt = code;
      const result = await invokeAIAgent(systemPrompt, userPrompt);
      return result;
    } catch (error) {
      return `Error: ${error.message}`;
    }
  };

  const handleCommand = async (cmd) => {
    const newHistory = [...history, `C:\\Users\\User> ${cmd}`];
    setHistory(newHistory);
    setInput('');
    
    if (cmd.toLowerCase() === 'help') {
      newHistory.push('Available commands: help, clear, date, echo, ver, python');
      newHistory.push('Type "python" followed by Python code to execute');
      newHistory.push('');
      setHistory(newHistory);
    } else if (cmd.toLowerCase() === 'clear') {
      setHistory([]);
      return;
    } else if (cmd.toLowerCase() === 'date') {
      newHistory.push(new Date().toLocaleString());
      newHistory.push('');
      setHistory(newHistory);
    } else if (cmd.toLowerCase() === 'ver') {
      newHistory.push('AuraOS Version 1.0.0');
      newHistory.push('');
      setHistory(newHistory);
    } else if (cmd.toLowerCase().startsWith('echo ')) {
      newHistory.push(cmd.substring(5));
      newHistory.push('');
      setHistory(newHistory);
    } else if (cmd.toLowerCase().startsWith('python ')) {
      setProcessing(true);
      const pythonCode = cmd.substring(7);
      const output = await executePython(pythonCode);
      newHistory.push(output);
      newHistory.push('');
      setHistory(newHistory);
      setProcessing(false);
    } else if (cmd) {
      newHistory.push(`'${cmd}' is not recognized as a command.`);
      newHistory.push('');
      setHistory(newHistory);
    }
  };

  return (
    <div className="terminal" onClick={() => inputRef.current?.focus()}>
      <div className="term-output">
        {history.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
        {processing && <div style={{color: '#4caf50'}}>Executing Python code...</div>}
      </div>
      <div className="term-input-line">
        <span className="prompt">C:\Users\User&gt;</span>
        <input
          ref={inputRef}
          className="term-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !processing) {
              handleCommand(input);
            }
          }}
          disabled={processing}
          autoFocus
        />
      </div>
    </div>
  );
}
