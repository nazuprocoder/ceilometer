function NotepadApp() {
  const [content, setContent] = React.useState('');
  const [fontSize, setFontSize] = React.useState(14);
  const [wordWrap, setWordWrap] = React.useState(true);

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  const charCount = content.length;
  const lineCount = content.split('\n').length;

  const handleSave = () => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'document.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleOpen = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => setContent(e.target.result);
      reader.readAsText(file);
    }
  };

  return (
    <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
      <div className="app-menu">
        <label className="menu-item" style={{cursor: 'pointer'}}>
          Open
          <input type="file" accept=".txt" onChange={handleOpen} style={{display: 'none'}} />
        </label>
        <span className="menu-item" onClick={handleSave}>Save</span>
        <span className="menu-item" onClick={() => setWordWrap(!wordWrap)}>
          Word Wrap: {wordWrap ? 'On' : 'Off'}
        </span>
        <span className="menu-item">
          Font:
          <select value={fontSize} onChange={(e) => setFontSize(Number(e.target.value))} style={{marginLeft: '5px', background: 'transparent', border: '1px solid var(--border-color)', color: 'var(--text-color)'}}>
            <option value={12}>12</option>
            <option value={14}>14</option>
            <option value={16}>16</option>
            <option value={18}>18</option>
            <option value={20}>20</option>
          </select>
        </span>
      </div>
      <textarea 
        className="notepad-area" 
        placeholder="Start typing..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        style={{
          fontSize: `${fontSize}px`,
          whiteSpace: wordWrap ? 'pre-wrap' : 'pre'
        }}
      />
      <div style={{
        padding: '5px 10px',
        borderTop: '1px solid var(--border-color)',
        fontSize: '11px',
        display: 'flex',
        gap: '15px',
        background: 'rgba(128,128,128,0.05)'
      }}>
        <span>Lines: {lineCount}</span>
        <span>Words: {wordCount}</span>
        <span>Characters: {charCount}</span>
      </div>
    </div>
  );
}
