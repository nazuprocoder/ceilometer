function VideoEditorApp() {
  const [playing, setPlaying] = React.useState(false);

  return (
    <div className="vid-container">
      <div className="vid-preview">
        <canvas id="vid-canvas"></canvas>
        <div style={{
          position: 'absolute',
          color: '#888',
          fontSize: '14px'
        }}>
          Video Preview Area
        </div>
      </div>
      <div className="vid-timeline">
        <div style={{position: 'relative', height: '40px'}}>
          <div className="trk"></div>
          <div className="playhead"></div>
        </div>
      </div>
      <div className="vid-controls">
        <i 
          className={`fa-solid ${playing ? 'fa-pause' : 'fa-play'}`}
          style={{cursor: 'pointer'}}
          onClick={() => setPlaying(!playing)}
        ></i>
        <i className="fa-solid fa-stop" style={{cursor: 'pointer'}}></i>
        <i className="fa-solid fa-scissors" style={{cursor: 'pointer'}}></i>
        <i className="fa-solid fa-folder-open" style={{cursor: 'pointer'}}></i>
      </div>
    </div>
  );
}