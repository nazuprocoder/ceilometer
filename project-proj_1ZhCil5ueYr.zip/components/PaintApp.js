function PaintApp() {
  const canvasRef = React.useRef(null);
  const [isDrawing, setIsDrawing] = React.useState(false);
  const [color, setColor] = React.useState('#000000');
  const [brushSize, setBrushSize] = React.useState(2);
  const [tool, setTool] = React.useState('brush');

  const colors = ['#000000', '#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ffa500', '#800080'];

  React.useEffect(() => {
    clearCanvas();
  }, []);

  const startDrawing = (e) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.beginPath();
  };

  const draw = (e) => {
    if (!isDrawing && e.type !== 'mousedown') return;
    
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    
    ctx.strokeStyle = color;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  return (
    <div className="paint-container">
      <div className="paint-toolbar">
        <span style={{fontSize: '12px', marginRight: '10px'}}>Brush:</span>
        {colors.map(c => (
          <div
            key={c}
            className={`color-btn ${color === c ? 'active' : ''}`}
            style={{background: c}}
            onClick={() => setColor(c)}
          />
        ))}
        <input
          type="range"
          min="1"
          max="20"
          value={brushSize}
          onChange={(e) => setBrushSize(e.target.value)}
          style={{marginLeft: '10px'}}
        />
        <span style={{fontSize: '12px', marginLeft: '5px'}}>{brushSize}px</span>
        <button
          onClick={clearCanvas}
          style={{
            marginLeft: 'auto',
            padding: '5px 15px',
            border: '1px solid var(--border-color)',
            background: 'var(--window-bg)',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          Clear
        </button>
      </div>
      <div style={{flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#e0e0e0'}}>
        <canvas
          ref={canvasRef}
          className="paint-canvas"
          width={700}
          height={400}
          onMouseDown={startDrawing}
          onMouseUp={stopDrawing}
          onMouseMove={draw}
          onMouseLeave={stopDrawing}
        />
      </div>
    </div>
  );
}