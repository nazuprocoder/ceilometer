function MusicPlayerApp() {
  const [playing, setPlaying] = React.useState(false);
  const [currentTime, setCurrentTime] = React.useState(0);
  const [duration, setDuration] = React.useState(180);
  const [volume, setVolume] = React.useState(70);
  const [currentTrack, setCurrentTrack] = React.useState(0);

  const playlist = [
    { title: 'Neon Dreams', artist: 'Synthwave Collection', duration: '3:24' },
    { title: 'Digital Horizon', artist: 'Cyber Sound', duration: '4:12' },
    { title: 'Electric Pulse', artist: 'Wave Rider', duration: '3:45' },
    { title: 'Midnight Drive', artist: 'Retro Future', duration: '5:01' }
  ];

  React.useEffect(() => {
    let interval;
    if (playing) {
      interval = setInterval(() => {
        setCurrentTime(t => {
          if (t >= duration) {
            setPlaying(false);
            return 0;
          }
          return t + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [playing, duration]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div style={{height: '100%', display: 'flex', flexDirection: 'column', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'}}>
      <div style={{flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', color: 'white'}}>
        <div style={{
          width: '200px',
          height: '200px',
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          borderRadius: '10px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          marginBottom: '30px',
          boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
          animation: playing ? 'pulse 2s infinite' : 'none'
        }}>
          <i className="fa-solid fa-music" style={{fontSize: '64px', opacity: 0.8}}></i>
        </div>
        <h2 style={{margin: '10px 0', fontSize: '24px'}}>{playlist[currentTrack].title}</h2>
        <p style={{margin: '5px 0', opacity: 0.8}}>{playlist[currentTrack].artist}</p>
      </div>

      <div style={{padding: '20px', background: 'rgba(0,0,0,0.2)'}}>
        <div style={{display: 'flex', justifyContent: 'space-between', color: 'white', fontSize: '12px', marginBottom: '10px'}}>
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
        <input
          type="range"
          min="0"
          max={duration}
          value={currentTime}
          onChange={(e) => setCurrentTime(Number(e.target.value))}
          style={{width: '100%', marginBottom: '20px'}}
        />

        <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '20px', marginBottom: '20px'}}>
          <i className="fa-solid fa-backward" style={{fontSize: '24px', cursor: 'pointer', color: 'white'}} onClick={() => setCurrentTrack((currentTrack - 1 + playlist.length) % playlist.length)}></i>
          <div 
            onClick={() => setPlaying(!playing)}
            style={{
              width: '60px',
              height: '60px',
              borderRadius: '50%',
              background: 'white',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              cursor: 'pointer',
              boxShadow: '0 5px 15px rgba(0,0,0,0.3)'
            }}
          >
            <i className={`fa-solid ${playing ? 'fa-pause' : 'fa-play'}`} style={{fontSize: '24px', color: '#667eea', marginLeft: playing ? '0' : '3px'}}></i>
          </div>
          <i className="fa-solid fa-forward" style={{fontSize: '24px', cursor: 'pointer', color: 'white'}} onClick={() => setCurrentTrack((currentTrack + 1) % playlist.length)}></i>
        </div>

        <div style={{display: 'flex', alignItems: 'center', gap: '10px', color: 'white'}}>
          <i className="fa-solid fa-volume-low"></i>
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            style={{flex: 1}}
          />
          <span style={{fontSize: '12px', width: '35px'}}>{volume}%</span>
        </div>
      </div>

      <div style={{maxHeight: '150px', overflowY: 'auto', background: 'rgba(0,0,0,0.3)', padding: '10px'}}>
        {playlist.map((track, i) => (
          <div 
            key={i}
            onClick={() => setCurrentTrack(i)}
            style={{
              padding: '10px',
              borderRadius: '5px',
              cursor: 'pointer',
              background: i === currentTrack ? 'rgba(255,255,255,0.1)' : 'transparent',
              color: 'white',
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '5px'
            }}
          >
            <div>
              <div style={{fontWeight: i === currentTrack ? 'bold' : 'normal'}}>{track.title}</div>
              <div style={{fontSize: '11px', opacity: 0.7}}>{track.artist}</div>
            </div>
            <span style={{fontSize: '12px', opacity: 0.7}}>{track.duration}</span>
          </div>
        ))}
      </div>
    </div>
  );
}