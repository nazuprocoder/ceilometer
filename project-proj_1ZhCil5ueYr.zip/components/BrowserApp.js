function BrowserApp() {
  const [url, setUrl] = React.useState('https://www.bing.com');
  const [inputUrl, setInputUrl] = React.useState('https://www.bing.com');
  const [loading, setLoading] = React.useState(false);
  const [content, setContent] = React.useState('');
  const [error, setError] = React.useState('');
  const iframeRef = React.useRef(null);

  const loadPage = async (targetUrl) => {
    setLoading(true);
    setError('');
    
    try {
      const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(targetUrl)}`;
      const response = await fetch(proxyUrl);
      
      if (!response.ok) {
        throw new Error('Failed to load page');
      }
      
      let html = await response.text();
      
      const baseTag = `<base href="${targetUrl}">`;
      html = html.replace('<head>', `<head>${baseTag}`);
      
      setContent(html);
      setUrl(targetUrl);
    } catch (err) {
      setError(`Unable to load: ${err.message}`);
      console.error('Browser load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleNavigate = () => {
    let targetUrl = inputUrl.trim();
    if (!targetUrl) return;
    
    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
      targetUrl = 'https://' + targetUrl;
    }
    
    loadPage(targetUrl);
  };

  const handleRefresh = () => {
    loadPage(url);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleNavigate();
    }
  };

  React.useEffect(() => {
    loadPage(url);
  }, []);

  return (
    <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
      <div style={{
        padding: '10px',
        borderBottom: '1px solid var(--border-color)',
        display: 'flex',
        gap: '10px',
        alignItems: 'center',
        background: 'rgba(128,128,128,0.03)'
      }}>
        <i 
          className="fa-solid fa-rotate-right" 
          style={{cursor: 'pointer', padding: '5px'}}
          onClick={handleRefresh}
        ></i>
        <div style={{
          flex: 1,
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          padding: '8px 12px',
          border: '1px solid var(--border-color)',
          borderRadius: '20px',
          background: 'var(--window-bg)'
        }}>
          <i className="fa-solid fa-globe" style={{fontSize: '12px'}}></i>
          <input
            type="text"
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Enter URL..."
            style={{
              flex: 1,
              border: 'none',
              outline: 'none',
              background: 'transparent',
              color: 'var(--text-color)',
              fontSize: '14px'
            }}
          />
          <i 
            className="fa-solid fa-arrow-right" 
            style={{cursor: 'pointer', fontSize: '14px', color: 'var(--accent-color)', padding: '5px'}}
            onClick={handleNavigate}
          ></i>
        </div>
      </div>
      {loading && (
        <div style={{
          padding: '8px 15px',
          background: 'rgba(0, 120, 212, 0.1)',
          fontSize: '12px',
          color: 'var(--accent-color)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <i className="fa-solid fa-spinner fa-spin"></i>
          Loading page content...
        </div>
      )}
      {error && (
        <div style={{
          padding: '8px 15px',
          background: 'rgba(255, 0, 0, 0.1)',
          fontSize: '12px',
          color: '#d32f2f',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <i className="fa-solid fa-circle-exclamation"></i>
          {error}
        </div>
      )}
      <div style={{flex: 1, position: 'relative', background: 'white', overflow: 'auto'}}>
        <iframe
          ref={iframeRef}
          srcDoc={content}
          style={{
            width: '100%',
            height: '100%',
            border: 'none'
          }}
          sandbox="allow-scripts allow-same-origin allow-forms"
          title="Browser Content"
        />
      </div>
    </div>
  );
}
