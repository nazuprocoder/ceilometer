function SettingsApp() {
  const [theme, setTheme] = React.useState('auto');
  const [notifications, setNotifications] = React.useState(true);
  const [soundEnabled, setSoundEnabled] = React.useState(true);
  const [animationsEnabled, setAnimationsEnabled] = React.useState(true);

  const settingsSections = [
    { id: 'system', icon: 'fa-desktop', label: 'System' },
    { id: 'display', icon: 'fa-tv', label: 'Display' },
    { id: 'sound', icon: 'fa-volume-high', label: 'Sound' },
    { id: 'privacy', icon: 'fa-lock', label: 'Privacy' },
    { id: 'accounts', icon: 'fa-user', label: 'Accounts' },
    { id: 'about', icon: 'fa-circle-info', label: 'About' }
  ];

  const [activeSection, setActiveSection] = React.useState('system');

  return (
    <div style={{height: '100%', display: 'flex'}}>
      <div style={{width: '200px', borderRight: '1px solid var(--border-color)', padding: '15px', background: 'rgba(128,128,128,0.03)'}}>
        {settingsSections.map(section => (
          <div
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            style={{
              padding: '12px',
              borderRadius: '6px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '5px',
              background: activeSection === section.id ? 'var(--accent-color)' : 'transparent',
              color: activeSection === section.id ? 'white' : 'var(--text-color)',
              transition: '0.2s'
            }}
          >
            <i className={`fa-solid ${section.icon}`}></i>
            <span style={{fontSize: '14px'}}>{section.label}</span>
          </div>
        ))}
      </div>
      <div style={{flex: 1, padding: '20px', overflowY: 'auto'}}>
        {activeSection === 'system' && (
          <div>
            <h2 style={{marginBottom: '20px', fontSize: '24px'}}>System Settings</h2>
            <div style={{marginBottom: '25px'}}>
              <label style={{display: 'block', marginBottom: '8px', fontWeight: 600}}>Theme</label>
              <select value={theme} onChange={(e) => setTheme(e.target.value)} style={{padding: '8px', width: '200px', border: '1px solid var(--border-color)', borderRadius: '4px', background: 'var(--window-bg)', color: 'var(--text-color)'}}>
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="auto">Auto</option>
              </select>
            </div>
            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer'}}>
                <input type="checkbox" checked={notifications} onChange={(e) => setNotifications(e.target.checked)} />
                <span>Enable notifications</span>
              </label>
            </div>
            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer'}}>
                <input type="checkbox" checked={animationsEnabled} onChange={(e) => setAnimationsEnabled(e.target.checked)} />
                <span>Enable animations</span>
              </label>
            </div>
          </div>
        )}
        {activeSection === 'about' && (
          <div>
            <h2 style={{marginBottom: '20px', fontSize: '24px'}}>About AuraOS</h2>
            <div style={{display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '30px'}}>
              <i className="fa-brands fa-windows" style={{fontSize: '64px', color: '#00a2ed'}}></i>
              <div>
                <h3 style={{margin: '0 0 10px 0'}}>AuraOS</h3>
                <p style={{margin: '5px 0', color: '#888'}}>Version 1.0.0</p>
                <p style={{margin: '5px 0', color: '#888'}}>© 2025 AuraOS Corporation</p>
              </div>
            </div>
            <div style={{padding: '15px', background: 'rgba(128,128,128,0.05)', borderRadius: '8px'}}>
              <p style={{margin: '0 0 10px 0', fontWeight: 600}}>System Information</p>
              <p style={{margin: '5px 0', fontSize: '13px'}}>Browser: Chrome/Edge</p>
              <p style={{margin: '5px 0', fontSize: '13px'}}>Platform: Web</p>
              <p style={{margin: '5px 0', fontSize: '13px'}}>Architecture: x64</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}