# AuraOS Web Experience

A complete web-based operating system simulation built with React.

## Features

- **Boot Screen**: Realistic OS boot animation
- **Desktop Environment**: Interactive desktop with icons
- **Window Manager**: Open, minimize, maximize, and close windows
- **Applications**:
  - File Explorer
  - Notepad
  - Terminal
  - Browser
  - Calculator
  - Cyber Snake Game
- **Start Menu**: Windows-style start menu with pinned apps
- **Taskbar**: Live clock, system tray, and window indicators
- **BSOD**: Blue Screen of Death simulation

## Technical Stack

- React 18
- TailwindCSS
- Font Awesome icons
- Pure CSS animations

## Design

The design features an Acrylic/Fluent Design System inspired aesthetic with:
- Glassmorphism effects
- Smooth animations
- Light/Dark mode support
- Modern Windows-style UI

Last Updated: 2025-10-20