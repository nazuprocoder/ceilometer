When project updates occur
- Check if README.md in trickle/notes needs updating
- Update feature list if new functionality is added
- Update technical information if dependencies change
- Update last updated date